import javax.swing.JFrame;

public class SnowmanDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SnowmanFrame Snowman = new SnowmanFrame();
		Snowman.setTitle("행복한 눈사람");
		Snowman.setSize(300,350);
		Snowman.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Snowman.setVisible(true);
	}

}
