import java.awt.Graphics;
import javax.swing.JFrame;

public class SnowmanFrame extends JFrame {
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		g.drawOval(100,50,100,100);
		g.drawOval(80,150,140,140);
		g.fillRect(120,80,20,5);
		g.fillRect(160,80,20,5);
		g.fillOval(145,100,10,10);
		g.drawArc(120,100,60,30,180,180);
	}

}
